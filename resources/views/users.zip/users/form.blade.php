<div id="staffmember-form-section" class="card admin-form-section" style="">
	<div class="card-header header-elements-inline">
		<h5 class="card-title ng-binding">Create User</h5>
		<div class="header-elements">
			<div class="list-icons">
				<a class="list-icons-item" data-action="collapse"></a>
				<a class="list-icons-item d-block" ng-click="revert()" data-action="remove"></a>
			</div>
		</div>
	</div>

	<div class="card-body">
		<form name="myForm" confirm-on-exit="" class="ng-pristine ng-valid-maxlength ng-invalid ng-invalid-required ng-valid-md-multiple">
			<div class="row">
				<div class="col-md-6">
					<fieldset>
						<!-- <legend class="font-weight-semibold"><i class="icon-reading mr-2"></i>User Information</legend> -->
							<!-- display errors -->
<!-- ngIf: errors -->
<!-- display errors -->
<!-- display success -->
<!-- <div class="alert alert-success" ng-if="successMsg" ng-cloak>
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
    <li ng-cloak ng-repeat="msg in successMsg">[[ msg ]]</li>
    
</div> -->
<!-- display success -->							<div class="form-group row">
								<div class="col-md-12">
									<label class="col-form-label font-w-500 txt-unln">1. User Information:</label>
								</div>
								<div class="col-lg-12">
									<div class="row">
										<label class="col-lg-3 col-form-label">Profile Picture</label>
										<div class="col-lg-3">
											<div class="wrapper prof-wrap">
												<img id="preview" style="width:100px;height: 100px;" class="output_image" ng-src="https://pwcenter.org/sites/default/files/default_images/default_profile.png" src="https://pwcenter.org/sites/default/files/default_images/default_profile.png">
												<div class="custom-file">
													<input name="logo" type="file" class="custom-file-input logo" form="logo-form">
													<label class="custom-file-label" for="customFile">Choose file</label>
												</div>
											</div>
										</div>
										<div class="col-lg-6">
											<div class="btns-div">
												<button ng-hide="staffForm.picture" name="staff" class="btn m-b-xs w-auto btn-success upload-logo legitRipple" type="button" aria-hidden="false"><i class="icon-upload"></i> Upload</button>
												<button ng-show="staffForm.picture" class="btn m-b-xs w-auto btn-danger legitRipple ng-hide" type="button" ng-click="clearPicture('staff')" aria-hidden="true"><i class="icon-cancel-circle2"></i> Remove</button>
											</div>

										</div>

									</div>
								</div>
								<div class="col-lg-6">
									<label class="col-form-label">First Name <span class="required">*</span></label>
									<input ng-model="staffForm.first_name" type="text" placeholder="John" class="form-control ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
								</div>
								<div class="col-lg-6">
									<label class="col-form-label">Last Name <span class="required">*</span></label>
									<input ng-model="staffForm.last_name" type="text" placeholder="Doe" class="form-control ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
								</div>
							</div>

							<div class="form-group row">
								<div class="col-lg-6">
									<label class="col-form-label">Email <span class="required">*</span></label>
									<input ng-model="staffForm.email" type="text" placeholder="email@example.com" class="form-control ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
                                </div>
                                <div class="col-lg-6">
                                        <label class="col-form-label">Phone <span class="required">*</span></label>
										<input ng-model="staffForm.phone" type="text" placeholder="(111) 111-1111" class="form-control phone_us ng-pristine ng-untouched ng-valid ng-empty ng-valid-maxlength" maxlength="14" aria-invalid="false">
                                </div>
								<!-- <div class="col-lg-6">
									<label class="col-form-label">Alternate Email</label>
									<input ng-model="staffForm.alternate_email" type="text" placeholder="email2@example.com" class="form-control ng-pristine ng-untouched ng-valid ng-empty" aria-invalid="false">
								</div> -->
							</div>

							<div class="form-group row membershiptype">
								<div class="col-lg-6">
									<label class="col-form-label">Role <span class="required">*</span></label>
									<md-select ng-model-options="{trackBy: '$value.id'}" placeholder="Select role(s)" ng-change="onSelectRole()" ng-model="staffForm.roles" aria-label="Role" multiple="" class="ng-pristine ng-valid ng-empty ng-valid-md-multiple ng-touched" tabindex="0" aria-disabled="false" role="listbox" aria-expanded="false" aria-multiselectable="true" id="select_14" aria-invalid="false" aria-owns="select_container_15" style=""><md-select-value class="md-select-value md-select-placeholder" id="select_value_label_1"><span>Select role(s)</span><span class="md-select-icon" aria-hidden="true"></span></md-select-value></md-select>
								</div>
								<div ng-show="isMember" class="col-lg-6 ng-hide" aria-hidden="true">
									<label class="col-form-label">Membership Level</label>
									<md-select ng-model-options="{trackBy: '$value.id'}" ng-model="staffForm.membership_level" class="ng-pristine ng-untouched ng-valid ng-empty" tabindex="0" aria-disabled="false" role="listbox" aria-expanded="false" aria-multiselectable="false" id="select_16" aria-invalid="false"><md-select-value class="md-select-value md-select-placeholder" id="select_value_label_2"><span></span><span class="md-select-icon" aria-hidden="true"></span></md-select-value><div class="md-select-menu-container" aria-hidden="true" role="presentation" id="select_container_17"><md-select-menu role="presentation" class="_md"><md-content class="_md">
										<!-- ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_56" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Platinum family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_57" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Gold family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_58" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Silver family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_59" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Plain Member family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_60" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">TEST LEVEL family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_61" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">test level family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_62" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Privilged Class Member family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_63" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">premium family</div></md-option><!-- end ngRepeat: membership in memberLevels --><md-option ng-value="membership" ng-repeat="membership in memberLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_64" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">qwert family</div></md-option><!-- end ngRepeat: membership in memberLevels -->
									</md-content></md-select-menu></div></md-select>
								</div>
								<div ng-show="isDonor" class="col-lg-6 ng-hide" aria-hidden="true">
									<label class="col-form-label">Donor Level</label>
									<md-select ng-model-options="{trackBy: '$value.id'}" ng-model="staffForm.membership_level" class="ng-pristine ng-untouched ng-valid ng-empty" tabindex="0" aria-disabled="false" role="listbox" aria-expanded="false" aria-multiselectable="false" id="select_18" aria-invalid="false"><md-select-value class="md-select-value md-select-placeholder" id="select_value_label_3"><span></span><span class="md-select-icon" aria-hidden="true"></span></md-select-value><div class="md-select-menu-container" aria-hidden="true" role="presentation" id="select_container_19"><md-select-menu role="presentation" class="_md"><md-content class="_md">
										<!-- ngRepeat: membership in donorLevels --><md-option ng-value="membership" ng-repeat="membership in donorLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_65" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Platinum family</div></md-option><!-- end ngRepeat: membership in donorLevels --><md-option ng-value="membership" ng-repeat="membership in donorLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_66" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Gold family</div></md-option><!-- end ngRepeat: membership in donorLevels --><md-option ng-value="membership" ng-repeat="membership in donorLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_67" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">Silver family</div></md-option><!-- end ngRepeat: membership in donorLevels --><md-option ng-value="membership" ng-repeat="membership in donorLevels" tabindex="0" class="ng-scope md-ink-ripple" role="option" aria-selected="false" id="select_option_68" aria-checked="true" value="[object Object]" style=""><div class="md-text ng-binding">TEST LEVEL family</div></md-option><!-- end ngRepeat: membership in donorLevels -->
									</md-content></md-select-menu></div></md-select>
								</div>
								<div ng-show="isVolunteer" class="col-lg-6 ng-hide" aria-hidden="true">
									<label class="col-form-label">Volunteer Type <span class="required">*</span></label>
									<md-select ng-model="staffForm.vol_status" placeholder="Select Status" class="ng-pristine ng-untouched ng-valid ng-empty" tabindex="0" aria-disabled="false" role="listbox" aria-expanded="false" aria-multiselectable="false" id="select_23" aria-invalid="false" aria-label="Select Status"><md-select-value class="md-select-value md-select-placeholder" id="select_value_label_4"><span>Select Status</span><span class="md-select-icon" aria-hidden="true"></span></md-select-value><div class="md-select-menu-container" aria-hidden="true" role="presentation" id="select_container_24"><md-select-menu role="presentation" class="_md"><md-content class="_md">
										<md-option value="Trainee" tabindex="0" class="md-ink-ripple" role="option" aria-selected="false" id="select_option_20"><div class="md-text">Trainee</div></md-option>
										<md-option value="Docent" tabindex="0" class="md-ink-ripple" role="option" aria-selected="false" id="select_option_21"><div class="md-text">Docent</div></md-option>
										<md-option value="Volunteer" tabindex="0" class="md-ink-ripple" role="option" aria-selected="false" id="select_option_22"><div class="md-text">Volunteer</div></md-option>
										
									</md-content></md-select-menu></div></md-select>
                                </div>
                                


                            </div>
                            

                            <div class="form-group row">
								<div class="col-lg-6">
									<label class="col-form-label">ID Card # </label>
									<input  ng-model="staffForm.idCardno" type="text" class="form-control">
									
                                </div>
                                <div class="col-lg-6">
									<label class="col-form-label">ID Card Expiration Date <span class="required">*</span></label>
									<div class="input-group">
										<span class="input-group-prepend">
											<span class="input-group-text"><i class="icon-calendar"></i></span>
										</span>
										<input date="" required="" ng-model="staffForm.dob" type="text" class="form-control pickadate-accessibility picker__input ng-pristine ng-untouched ng-empty ng-invalid ng-invalid-required" readonly="" id="P620954496" aria-haspopup="true" aria-expanded="false" aria-readonly="false" aria-owns="P620954496_root" aria-invalid="true"><div class="picker" id="P620954496_root" aria-hidden="true"><div class="picker__holder" tabindex="-1"><div class="picker__frame"><div class="picker__wrap"><div class="picker__box"><div class="picker__header"><select class="picker__select--year" disabled="" aria-controls="P620954496_table" title="Pick a year from the dropdown"><option value="1941">1941</option><option value="1942">1942</option><option value="1943">1943</option><option value="1944">1944</option><option value="1945">1945</option><option value="1946">1946</option><option value="1947">1947</option><option value="1948">1948</option><option value="1949">1949</option><option value="1950">1950</option><option value="1951">1951</option><option value="1952">1952</option><option value="1953">1953</option><option value="1954">1954</option><option value="1955">1955</option><option value="1956">1956</option><option value="1957">1957</option><option value="1958">1958</option><option value="1959">1959</option><option value="1960">1960</option><option value="1961">1961</option><option value="1962">1962</option><option value="1963">1963</option><option value="1964">1964</option><option value="1965">1965</option><option value="1966">1966</option><option value="1967">1967</option><option value="1968">1968</option><option value="1969">1969</option><option value="1970">1970</option><option value="1971">1971</option><option value="1972">1972</option><option value="1973">1973</option><option value="1974">1974</option><option value="1975">1975</option><option value="1976">1976</option><option value="1977">1977</option><option value="1978">1978</option><option value="1979">1979</option><option value="1980">1980</option><option value="1981">1981</option><option value="1982">1982</option><option value="1983">1983</option><option value="1984">1984</option><option value="1985">1985</option><option value="1986">1986</option><option value="1987">1987</option><option value="1988">1988</option><option value="1989">1989</option><option value="1990">1990</option><option value="1991">1991</option><option value="1992">1992</option><option value="1993">1993</option><option value="1994">1994</option><option value="1995">1995</option><option value="1996">1996</option><option value="1997">1997</option><option value="1998">1998</option><option value="1999">1999</option><option value="2000">2000</option><option value="2001">2001</option><option value="2002">2002</option><option value="2003">2003</option><option value="2004">2004</option><option value="2005">2005</option><option value="2006">2006</option><option value="2007">2007</option><option value="2008">2008</option><option value="2009">2009</option><option value="2010">2010</option><option value="2011">2011</option><option value="2012">2012</option><option value="2013">2013</option><option value="2014">2014</option><option value="2015">2015</option><option value="2016">2016</option><option value="2017">2017</option><option value="2018">2018</option><option value="2019">2019</option><option value="2020">2020</option><option value="2021" selected="">2021</option></select><select class="picker__select--month" disabled="" aria-controls="P620954496_table" title="Pick a month from the dropdown"><option value="0" selected="">January</option><option value="1" disabled="">February</option><option value="2" disabled="">March</option><option value="3" disabled="">April</option><option value="4" disabled="">May</option><option value="5" disabled="">June</option><option value="6" disabled="">July</option><option value="7" disabled="">August</option><option value="8" disabled="">September</option><option value="9" disabled="">October</option><option value="10" disabled="">November</option><option value="11" disabled="">December</option></select><div class="picker__nav--prev" data-nav="-1" role="button" aria-controls="P620954496_table" title="Go to the previous month"> </div><div class="picker__nav--next picker__nav--disabled" data-nav="1" role="button" aria-controls="P620954496_table" title="Go to the next month"> </div></div><table class="picker__table" id="P620954496_table" role="grid" aria-controls="P620954496" aria-readonly="true"><thead><tr><th class="picker__weekday" scope="col" title="Sunday">Sun</th><th class="picker__weekday" scope="col" title="Monday">Mon</th><th class="picker__weekday" scope="col" title="Tuesday">Tue</th><th class="picker__weekday" scope="col" title="Wednesday">Wed</th><th class="picker__weekday" scope="col" title="Thursday">Thu</th><th class="picker__weekday" scope="col" title="Friday">Fri</th><th class="picker__weekday" scope="col" title="Saturday">Sat</th></tr></thead><tbody><tr><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1609045200000" role="gridcell" aria-label="12/27/2020">27</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1609131600000" role="gridcell" aria-label="12/28/2020">28</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1609218000000" role="gridcell" aria-label="12/29/2020">29</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1609304400000" role="gridcell" aria-label="12/30/2020">30</div></td><td role="presentation"><div class="picker__day picker__day--outfocus" data-pick="1609390800000" role="gridcell" aria-label="12/31/2020">31</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609477200000" role="gridcell" aria-label="1/1/2021">1</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609563600000" role="gridcell" aria-label="1/2/2021">2</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609650000000" role="gridcell" aria-label="1/3/2021">3</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609736400000" role="gridcell" aria-label="1/4/2021">4</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609822800000" role="gridcell" aria-label="1/5/2021">5</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609909200000" role="gridcell" aria-label="1/6/2021">6</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1609995600000" role="gridcell" aria-label="1/7/2021">7</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610082000000" role="gridcell" aria-label="1/8/2021">8</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610168400000" role="gridcell" aria-label="1/9/2021">9</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610254800000" role="gridcell" aria-label="1/10/2021">10</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610341200000" role="gridcell" aria-label="1/11/2021">11</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610427600000" role="gridcell" aria-label="1/12/2021">12</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610514000000" role="gridcell" aria-label="1/13/2021">13</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610600400000" role="gridcell" aria-label="1/14/2021">14</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610686800000" role="gridcell" aria-label="1/15/2021">15</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610773200000" role="gridcell" aria-label="1/16/2021">16</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610859600000" role="gridcell" aria-label="1/17/2021">17</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1610946000000" role="gridcell" aria-label="1/18/2021">18</div></td><td role="presentation"><div class="picker__day picker__day--infocus" data-pick="1611032400000" role="gridcell" aria-label="1/19/2021">19</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--today picker__day--highlighted" data-pick="1611118800000" role="gridcell" aria-label="1/20/2021" aria-activedescendant="true">20</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611205200000" role="gridcell" aria-label="1/21/2021" aria-disabled="true">21</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611291600000" role="gridcell" aria-label="1/22/2021" aria-disabled="true">22</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611378000000" role="gridcell" aria-label="1/23/2021" aria-disabled="true">23</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611464400000" role="gridcell" aria-label="1/24/2021" aria-disabled="true">24</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611550800000" role="gridcell" aria-label="1/25/2021" aria-disabled="true">25</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611637200000" role="gridcell" aria-label="1/26/2021" aria-disabled="true">26</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611723600000" role="gridcell" aria-label="1/27/2021" aria-disabled="true">27</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611810000000" role="gridcell" aria-label="1/28/2021" aria-disabled="true">28</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611896400000" role="gridcell" aria-label="1/29/2021" aria-disabled="true">29</div></td><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1611982800000" role="gridcell" aria-label="1/30/2021" aria-disabled="true">30</div></td></tr><tr><td role="presentation"><div class="picker__day picker__day--infocus picker__day--disabled" data-pick="1612069200000" role="gridcell" aria-label="1/31/2021" aria-disabled="true">31</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612155600000" role="gridcell" aria-label="2/1/2021" aria-disabled="true">1</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612242000000" role="gridcell" aria-label="2/2/2021" aria-disabled="true">2</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612328400000" role="gridcell" aria-label="2/3/2021" aria-disabled="true">3</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612414800000" role="gridcell" aria-label="2/4/2021" aria-disabled="true">4</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612501200000" role="gridcell" aria-label="2/5/2021" aria-disabled="true">5</div></td><td role="presentation"><div class="picker__day picker__day--outfocus picker__day--disabled" data-pick="1612587600000" role="gridcell" aria-label="2/6/2021" aria-disabled="true">6</div></td></tr></tbody></table><div class="picker__footer"><button class="picker__button--today" type="button" data-pick="1611118800000" disabled="" aria-controls="P620954496">Today</button><button class="picker__button--clear" type="button" data-clear="1" disabled="" aria-controls="P620954496">Clear</button><button class="picker__button--close" type="button" data-close="true" disabled="" aria-controls="P620954496">Close</button></div></div></div></div></div></div>
									</div>
								</div>

							</div>

					</fieldset>
				</div>
				<div class="col-md-6">
					<div class="row">
						<div class="col-md-12">
							<!-- Address list -->
							<div class="card">
								<div class="card-header header-elements-inline">
									<h5 class="card-title">Addresses</h5>
									<div class="header-elements">
										<div class="list-icons">
											<a class="list-icons-item" ng-click="showAddressModal()" data-popup="tooltip" title="" data-trigger="hover" data-original-title="Add New Address"><i class="icon-plus2"></i></a>
											<a class="list-icons-item" data-action="collapse"></a>
										</div>
									</div>
								</div>

								<div class="card-body" style="">
									<ul class="media-list">
										<!-- ngRepeat: address in staffForm.addresses -->


									</ul>
								</div>
							</div>
							<!-- /Address list -->
						</div>
					

						<!-- ngIf: isMember || isDonor -->
					</div>

				</div>
			</div>
			<div class="text-right">
				<button type="button" ng-click="createStaff()" class="btn btn-primary legitRipple ng-binding"><i class="icon-floppy-disk ml-2"></i>Add </button>
				<button type="submit" class="btn btn-primary admin-form-close legitRipple" ng-click="revert()">Cancel <i class="icon-close2 ml-2"></i></button>
			</div>
		</form>
		<form action="saveProfilePicture" method="post" enctype="multipart/form-data" id="logo-form" onsubmit="return false;" class="ng-pristine ng-valid"></form>
	</div>
	
</div>